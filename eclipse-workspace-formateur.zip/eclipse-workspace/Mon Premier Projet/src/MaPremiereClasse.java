
public class MaPremiereClasse {

	public static void main(String[] args) {

		/*
		 * Commentaire
		 * sur plusieurs
		 * lignes...
		 */
		System.out.println("Hello World !!!");		// Affichage d'un message
		
		final int NB_ELEMENTS = 0;
		
		// NB_ELEMENTS = 1;
		
		System.out.println(NB_ELEMENTS);
		
		char c = 'f';
		
		System.out.println(" --- Les Tableaux --- ");
		
		// 1. D�claration et dimensionnement
		int[] tabEntiers1;			// ou : int tabEntiers1[]; 
		tabEntiers1 = new int[4];	// 4 cases

		tabEntiers1[0] = 100;
		tabEntiers1[1] = 200;
		tabEntiers1[2] = 300;
		tabEntiers1[3] = 400;
		
		// Sur une seule ligne : 
		//
		// int[] tabEntiers1 = new int[4];
		
		
		// 2. D�clarer et remplir un tableau
		int[] tabEntiers2 = {10, 20, 30, 40};		// 4 valeurs -> 4 cases
		
		System.out.println("El�ment � la case 1 du premier tableau : " + tabEntiers1[1]);
		System.out.println("El�ment � la case 1 du second tableau : " + tabEntiers2[1]);

		System.out.println("Taille de tabEntiers1 : " + tabEntiers1.length);
		
		System.out.println(" --- Les chaines de caract�res --- ");
		
		String chaine1 = "Ceci est une chaine de caract�res.";
		String chaine2 = "Une autre chaine...";
		
		String chaine3 = chaine1 + " " + chaine2;
		
		System.out.println(chaine3);
		
		System.out.println("chaine3 fait " + chaine3.length() + " caract�res.");
		
		System.out.println(chaine3.toUpperCase());
		
		System.out.println(" --- if / else --- ");
		
		int a = 1;
		
		if(a == 0) {
			System.out.println("a vaut 0");
		}
		else if(a == 1) {
			System.out.println("a vaut 1");
		}
		else if(a == 2) {
			System.out.println("a vaut 2");
		}
		else {
			System.out.println("Valeur inconnue !");
		}
		
		System.out.println(" --- switch / case --- ");
		// ATTENTION AU break !
		switch(a) {
			case 0:  System.out.println("a vaut 0");
					 break;
			case 1:  System.out.println("a vaut 1");
					 break;
			case 2:  System.out.println("a vaut 2");
					 break;
			default: System.out.println("Valeur inconnue !");
		}
		
		System.out.println(" --- for ---");
		
		// On travaille avec un indice pour parcourir toutes les cases d'un tableau
		for(int indice = 0; indice < tabEntiers2.length; indice++) {
			System.out.println("Element � l'indice " + indice + " = " + tabEntiers2[indice]);
		}
		
		System.out.println(" --- 'Enhanced' for ---");
		
		for(int valeur : tabEntiers2) { // Pour chaque valeur de tabEntiers2...
			System.out.println("Element vaut : " + valeur);
		}
		
	}

}

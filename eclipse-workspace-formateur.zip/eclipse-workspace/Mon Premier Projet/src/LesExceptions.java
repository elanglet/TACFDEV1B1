
public class LesExceptions {

	public static void main(String[] args) {

		System.out.println(" *** D�but du programme *** ");
		
		try {
			int a = 10;
			int b = 0;
			
			System.out.println(a / b);
		}
		// La variable 'e' repr�sente l'objet d'exception. 
		catch(Exception e) {
			// Journaliser l'erreur dans un fichier journal...
			
			System.out.println("Erreur ! Message : " + e.getMessage());
		}
		
		System.out.println(" *** Fin du programme *** ");		
	}

}

module fr.formation.banque {
	exports fr.formation.banque;
	exports fr.formation.banque.exceptions;
	exports fr.formation.banque.produit;
	exports fr.formation.banque.portefeuille;
	
	requires org.apache.logging.log4j;
	requires org.junit.jupiter.api;
}

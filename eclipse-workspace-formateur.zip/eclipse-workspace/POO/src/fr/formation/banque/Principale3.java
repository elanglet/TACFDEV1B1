package fr.formation.banque;

import java.util.ArrayList;
import java.util.HashMap;

import fr.formation.banque.exceptions.CompteException;
import fr.formation.banque.exceptions.OperationException;
import fr.formation.banque.portefeuille.Client;
import fr.formation.banque.produit.CompteCourant;

public class Principale3 {

	public static void main(String[] args) {
		
		System.out.println(" --- Travail avec les ArrayList --- ");
		
		Client client1 = new Client(1, "DUPONT", "Robert", "40 rue de la Paix", "75007", "Paris");
		Client client2 = new Client(2, "DURAND", "St�phane", "Place du Ralliement", "49000", "Angers");
		Client client3 = new Client(3, "MENARD", "Sylvie", "rue Condorcet", "44100", "Nantes");
		
		// On cr�� un ArrayList de Client
		ArrayList<Client> listeDesClients = new ArrayList<Client>();
		
		listeDesClients.add(client1);
		listeDesClients.add(client2);
		listeDesClients.add(client3);
		
		// Connaitre la taille de la liste
		System.out.println("Taille de la liste : " + listeDesClients.size());
		
		// R�cup�rer un �l�ment � un indice donn�
		Client clientRecupere = listeDesClients.get(1);
		System.out.println("Client r�cup�r� : " + clientRecupere.getId() + " " + clientRecupere.getPrenom() + " " + clientRecupere.getNom());
		
		// Supprimer un �l�ment
		listeDesClients.remove(0);
		System.out.println("Taille de la liste : " + listeDesClients.size());
		
		// Parcourir la liste
		System.out.println(" * Parcourir la liste * ");
		for(Client clt : listeDesClients) {
			System.out.println(clt.getId() + " " + clt.getPrenom() + " " + clt.getNom());

		}
		
		try {
			System.out.println(" --- Travail avec les HashMap --- ");

			CompteCourant comptecourant1 = new CompteCourant(562369, 100.00, client1, 500.00);
			CompteCourant comptecourant2 = new CompteCourant(896452, 25000.00, client2, 800.00);
			CompteCourant comptecourant3 = new CompteCourant(235745, 333.00, client3, 200.00);
			
			comptecourant1.debiter(800);
			comptecourant2.crediter(500);
			comptecourant3.debiter(100);
			
			HashMap<Long, CompteCourant> listeDeComptes = new HashMap<Long, CompteCourant>();
			
			listeDeComptes.put(comptecourant1.getNumero(), comptecourant1);
			listeDeComptes.put(comptecourant2.getNumero(), comptecourant2);
			listeDeComptes.put(comptecourant3.getNumero(), comptecourant3);
			
			// Connaitre la taille de la HashMap
			System.out.println("Taille de la HashMap : " + listeDeComptes.size());
			
			// R�cup�rer une valeur par sa cl�
						
			// Le code ci dessous ne permet pas de r�cup�rer le compte � la cl� 896452 !
			// Car 896452 est un lit�ral de type 'int' alors qu'il nous faut un 'long' !!!
			// 
			// CompteCourant compteCourantRecupere = listeDeComptes.get(896452);
			
			CompteCourant compteCourantRecupere = listeDeComptes.get(896452L);
			// Ou : 
			// CompteCourant compteCourantRecupere = listeDeComptes.get( new Long(896452) );
			System.out.println("Solde du compte � la cl� 896452 : " + compteCourantRecupere.getSolde());
			
			// Supprimer une paire cl�/valeur
			listeDeComptes.remove(896452L);
			System.out.println("Taille de la HashMap : " + listeDeComptes.size());

			// Parcourir la HashMap
			
			// Il faut parcourir les cl�s, on obtient la liste des cl�s avec la m�thodes keySet()
			for(Long key : listeDeComptes.keySet()) {
				System.out.println("Solde du compte � la cl� " + key + " : " + listeDeComptes.get(key).getSolde());
			}
		} 
		catch (CompteException | OperationException e) {
			System.out.println("Erreur ! " + e.getMessage());
		}
	}

}

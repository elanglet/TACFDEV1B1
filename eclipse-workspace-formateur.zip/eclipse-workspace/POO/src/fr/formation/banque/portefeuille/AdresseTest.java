package fr.formation.banque.portefeuille;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AdresseTest {

	private Adresse adresse;
	
	@BeforeEach
	public void setUp() {
		// Il faut un objet de type Adresse avant l'ex�cution de chaque test !
		adresse = new Adresse("40 rue de la Paix", "75007", "Paris");
	}
	
	@Test
	void testAdresse() {
		Adresse adresse = new Adresse("Place du Ralliement", "49000", "Angers");
		assertEquals("Place du Ralliement", adresse.getRue());
		assertEquals("49000", adresse.getCodePostal());
		assertEquals("Angers", adresse.getVille());
	}

	@Test
	void testGetRue() {
		// Appeler la m�thode � tester
		String rue = adresse.getRue();
		// V�rifier que le r�sultat produit par la m�thode est conforme au r�sultat attendu : assertion
		// assertXXX(valeur attendue, valeur retourn�e)
		assertEquals("40 rue de la Paix", rue);
	}

	@Test
	void testSetRue() {
		adresse.setRue("3 rue Condorcet");
		// On a le droit d'utiliser getRue() pour valider ce test a condition que getRue() soit test�. 
		assertEquals("3 rue Condorcet", adresse.getRue());
	}

	@Test
	void testGetCodePostal() {
		String codePostal = adresse.getCodePostal();
		assertEquals("75007", codePostal);
	}

	@Test
	void testSetCodePostal() {
		adresse.setCodePostal("44100");
		assertEquals("44100", adresse.getCodePostal());
	}

	@Test
	void testGetVille() {
		assertEquals("Paris", adresse.getVille());
	}

	@Test
	void testSetVille() {
		adresse.setVille("Nantes");
		assertEquals("Nantes", adresse.getVille());
	}
}

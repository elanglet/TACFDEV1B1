package fr.formation.banque.portefeuille;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Client {

	private static Logger logger = LogManager.getLogger(Client.class);
	
	private long id;
	private String nom;
	private String prenom;
	
	// Attributs d�plac�s dans un objet Adresse
	
	// private String adresse;
	// private String codePostal;
	// private String ville;
	
	// Composition avec un objet Adresse : Quand on cr�� un objet Client, on cr�� aussi un objet Adresse
	private Adresse adresse;

	// Constructeur(s)
	public Client(long id, String nom, String prenom, String rue, String codePostal, String ville) {
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;

		// On cr�� l'objet Adresse
		this.adresse = new Adresse(rue, codePostal, ville);
		logger.debug("Cr�ation d'un nouveau client");
	}

	// M�thodes d'acc�s
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	public long getId() {
		return id;
	}
	
	// On red�finit la m�thode equals() pour pouvoir comparer 2 objets Client
	// On va appeler la m�thode entre 2 objets : 
	//
	//			clt1.equals(clt2)
	//
	// 	clt1 -> this
	//	clt2 -> obj
	//
	public boolean equals(Object obj) {
		// On commence par v�rifier que 'obj' est bien un Client...
		// ... puis on compare sur la base des id...
		if(obj instanceof Client) {
			// On transtype obj en Client
			Client client = (Client) obj;
			// On compare les id...
			if(this.id == client.id)		// == car id est un long !
				
			// if(this.nom.equals(client.nom)) // Exemple de comparaison sur les noms...	
				
				return true;
		}
		return false;
	}

}







package fr.formation.banque;

import fr.formation.banque.exceptions.CompteException;
import fr.formation.banque.exceptions.OperationException;
import fr.formation.banque.portefeuille.Client;
import fr.formation.banque.produit.AssuranceVie;
import fr.formation.banque.produit.CompteCourant;
import fr.formation.banque.produit.CompteEpargne;
import fr.formation.banque.produit.Placement;
import fr.formation.banque.produit.Produit;

public class Principale2 {

	public static void main(String[] args) {

		Client client1 = new Client(1, "DUPONT", "Robert", "40 rue de la Paix", "75007", "Paris");
		Client client2 = new Client(2, "DURAND", "St�phane", "Place du Ralliement", "49000", "Angers");
		
		try {
			System.out.println(" --- Utilisation des comptes courants --- ");
			
			CompteCourant cc1 = new CompteCourant(963123, 100.00, client1, 500.00);
			
			// cc1.debiter(900.00);
			cc1.debiter(50.00);
			
			System.out.println(
					cc1.getNumero() + " - " + cc1.getSolde() + ", Autorisation de d�couvert : " + cc1.getAutorisation() + " �"
			);

			System.out.println(" --- Utilisation des comptes �pargnes --- ");
			
			CompteEpargne ce1 = new CompteEpargne(456236, 20000.00, client2, 1.25, 23500.00);
			
			// ce1.crediter(5000.00);
			ce1.crediter(1000.00);
			
			System.out.println(
					ce1.getNumero() + " - " + ce1.getSolde() +
					", Taux : " + ce1.getTaux() + " %, Plafond : " + ce1.getPlafond() + " �"
			);
			
			System.out.println(" --- Utilisation des assurances vie --- ");
			
			AssuranceVie ass1 = new AssuranceVie(1.25, 500000.00, client2);
			
			System.out.println(
					ass1.getIndicePerformance() + " - Prime : " + ass1.getMontantPrime() +
					" �, souscrit par " + ass1.getClient().getPrenom() + " " + ass1.getClient().getNom()
			);
			
			System.out.println(" --- Manipulation des diff�rents produits bancaires --- ");
			// Pour regrouper tous les produits bancaires dans un ensemble, il faut cr�er un tableau de Produit
			Produit[] produitsBancaires = { cc1, ce1, ass1 };
			
			// Pour chaque 'produit' dans 'produitsBancaires'...
			for(Produit produit : produitsBancaires) {
				// Traitement de chaque produit ...
				
				// On veut r�mun�rer tous les placements !
				if(produit instanceof Placement) {
					// Ce produit est un Placement
					Placement placement = (Placement) produit;
					placement.remunerer();
				}
			}
		} 
		
//		catch (CompteException e) {
//			// e.printStackTrace();   -> Affiche la pile d'erreur comme quand l'exception n'est pas g�r�e.
//			System.err.println("Erreur ! Message : " + e.getMessage());
//		} 
//		catch (OperationException e) {
//			// e.printStackTrace();
//			System.err.println("Erreur ! Message : " + e.getMessage());
//		}

		// Ou avec un multi-catch !
		catch (OperationException | CompteException e ) {
			// e.printStackTrace();
			System.err.println("Erreur ! Message : " + e.getMessage());
		}
	}

}

package fr.formation.banque.produit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import fr.formation.banque.exceptions.CompteException;
import fr.formation.banque.exceptions.OperationException;
import fr.formation.banque.portefeuille.Client;

public abstract class Compte extends Produit {

	// D�claration du Logger Log4J
	private static Logger logger = LogManager.getLogger(Compte.class);
	
	// D�claration des attributs.
	private long numero;
	private double solde;
	private Client client;
	
	// Attribut de classe pour compter le nombre d'instances cr��es.
	private static int nbComptes = 0;
	
	// D�finition d'un constructeur pour initialiser les attributs.
	public Compte(long pNumero, double pSolde, Client pClient) throws CompteException {

		// On initialise les attributs avec les valeurs re�ues dans les param�tres.
		if(pNumero > 0) {
			numero = pNumero;
		}
		else {			
			logger.error("Le num�ro de compte doit �tre une valeur positive.");
			// On d�clenche une exception !
			
			// 1. Cr�er un objet d'exception
			CompteException e = new CompteException("Le num�ro de compte doit �tre une valeur positive.");
			// 2. D�clencher l'exception
			throw e;
		}
		
		if(pSolde > 0) {
			solde = pSolde;
		}
		else {
			logger.error("Le solde d'un nouveau compte doit �tre positif.");
			throw new CompteException("Le solde d'un nouveau compte doit �tre positif.");
		}
		
		if(pClient != null) {
			client = pClient;
		}
		else {
			logger.error("Le nouveau compte doit �tre associ� � un client.");
			throw new CompteException("Le nouveau compte doit �tre associ� � un client.");
		}
		
		// On incr�mente le nombre de comptes
		nbComptes++;
	}

	// Surcharge de constructeur : Un autre constructeur avec un nombre de
	// param�tres diff�rent.
	public Compte(long pNumero, Client pClient) throws CompteException {
		// numero = pNumero;
		// solde = 0.0;
		// client = pClient;
		//
		// Ou :
		//
		this(pNumero, 0.0, pClient); // On appelle le constructeur � 3 param�tres de cette classe.
	}

	// D�claration des m�thodes.
	public void debiter(double montant) throws OperationException {
		// Impl�mentation de la m�thode : Code interne
		solde = solde - montant; // solde -= montant;
		logger.info("D�bit de " + montant + " � sur le compte " + numero);
	}

	public void crediter(double montant) throws OperationException {
		solde = solde + montant; // solde += montant;
		logger.info("Cr�dit de " + montant + " � sur le compte " + numero);
	}

	// M�thodes d'acc�s en lecture et �criture
	public Client getClient() {
		return client;
	}

	public void setClient(Client client) throws CompteException {
		// On peut faire des contr�les sur les valeurs !
		if (client != null) {
			this.client = client;
		}
		else {
			logger.error("Le compte doit �tre associ� � un client.");
			throw new CompteException("Le compte doit �tre associ� � un client.");
		}
	}

	public long getNumero() {
		return numero;
	}

	public double getSolde() {
		return solde;
	}

	// M�thode de classe pour acc�der � l'attribut de classe.
	public static int getNbComptes() {
		return nbComptes;
	}
	
	// D�claration d'une m�thode abstraite (possible car cette classe Compte est abstraite).
	// Cette m�thodes devra �tre red�finie dans les sous-classes.
	public abstract void cloturer();
}

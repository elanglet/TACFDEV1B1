package fr.formation.banque.produit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import fr.formation.banque.exceptions.CompteException;
import fr.formation.banque.exceptions.OperationException;
import fr.formation.banque.portefeuille.Client;

public class CompteEpargne extends Compte implements Placement {

	private static Logger logger = LogManager.getLogger(CompteEpargne.class);
	
	private double taux;
	private double plafond;

	public CompteEpargne(long pNumero, double pSolde, Client pClient, double taux, double plafond) throws CompteException {
		super(pNumero, pSolde, pClient);
		this.taux = taux;
		this.plafond = plafond;
		logger.debug("Cr�ation d'un nouveau compte �pargne.");
	}

	public double getTaux() {
		return taux;
	}

	public void setTaux(double taux) {
		this.taux = taux;
	}

	public double getPlafond() {
		return plafond;
	}

	public void setPlafond(double plafond) {
		this.plafond = plafond;
	}

	// Red�finition des m�thodes debiter() et crediter()
	@Override
	public void debiter(double montant) throws OperationException {
		if((getSolde() - montant) >= 0) {
			super.debiter(montant);
		}
		else {
			logger.error("D�bit impossible, le solde ne peut �tre n�gatif.");
			throw new OperationException("D�bit impossible, le solde ne peut �tre n�gatif.");
		}
	}
	
	@Override
	public void crediter(double montant) throws OperationException {
		if((getSolde() + montant) <= plafond) {
			super.crediter(montant);
		}
		else {
			logger.error("Cr�dit impossible, le solde ne peut d�passer le plafond.");
			throw new OperationException("Cr�dit impossible, le solde ne peut d�passer le plafond.");
		}
	}

	@Override
	public void cloturer() {
		System.out.println("Cloture du compte �pargne en cours...");
	}

	@Override
	public void remunerer() {
		System.out.println("Calcul de la r�mun�ration du compte �pargne...");
	}
	
}

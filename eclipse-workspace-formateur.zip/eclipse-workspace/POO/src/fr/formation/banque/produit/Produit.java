package fr.formation.banque.produit;

public abstract class Produit {

}

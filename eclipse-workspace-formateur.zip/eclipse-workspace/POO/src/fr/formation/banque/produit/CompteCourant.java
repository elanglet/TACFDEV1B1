package fr.formation.banque.produit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import fr.formation.banque.exceptions.CompteException;
import fr.formation.banque.exceptions.OperationException;
import fr.formation.banque.portefeuille.Client;

public class CompteCourant extends Compte {

	private static Logger logger = LogManager.getLogger(CompteCourant.class);
	
	// Attributs qui s'ajoutent � ceux h�rit�s.
	private double autorisation;

	// Constructeur : On doit initialiser les attributs h�rit�s de Compte et ceux de CompteCourant
	public CompteCourant(long numero, double solde, Client client, double autorisation) throws CompteException {
		
		// Impossible : numero est private !
		// this.numero = numero;
		
		// On doit appeler le constructeur de la super classe pour initialiser les attributs h�rit�s.
		// L'appel au super constructeur doit �tre la premi�re instruction.
		super(numero, solde, client);
		
		if(autorisation > 0) {
			this.autorisation = autorisation;
		}
		else {
			logger.error("Le montant de l'autorisation de d�couvert doit �tre positif.");
			throw new CompteException("Le montant de l'autorisation de d�couvert doit �tre positif.");
		}
		logger.debug("Cr�ation d'un nouveau compte courant.");
	}
	
	public double getAutorisation() {
		return autorisation;
	}

	public void setAutorisation(double autorisation) {
		this.autorisation = autorisation;
	}

	// Red�finir la m�thode debiter() pour l'adapter aux contraintes d'un compte courant (Autorisation de d�couvert)
	public void debiter(double montant) throws OperationException {
		if( (getSolde() - montant) > -autorisation) {
			// On peut d�biter...
			// On appelle la m�thode debiter() de Compte
			super.debiter(montant);
		}
		else {
			// G�n�rer une erreur...
			logger.error("D�bit impossible, autorisation de d�couvert d�pass�e.");
			throw new OperationException("D�bit impossible, autorisation de d�couvert d�pass�e.");
		}
	}

	@Override
	public void cloturer() {
		System.out.println("Cloture du compte courant en cours...");
	}
	
}

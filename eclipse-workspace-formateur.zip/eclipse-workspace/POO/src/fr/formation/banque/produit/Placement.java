package fr.formation.banque.produit;

public interface Placement {

	// D�finition d'une m�thode dans l'interface
	// Elle est forc�ment public et abstract -> On pourrait s'affranchir des mots-cl�s
	public abstract void remunerer();
	
}

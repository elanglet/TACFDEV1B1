package fr.formation.banque.produit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import fr.formation.banque.portefeuille.Client;

public class AssuranceVie extends Produit implements Placement {

	private static Logger logger = LogManager.getLogger(AssuranceVie.class);
	
	private double indicePerformance;
	private double montantPrime;
	private Client client;

	public AssuranceVie(double indicePerformance, double montantPrime, Client client) {
		this.indicePerformance = indicePerformance;
		this.montantPrime = montantPrime;
		this.client = client;
		
		logger.debug("Cr�ation d'une nouveau contrat d'assurance vie.");

	}

	public double getIndicePerformance() {
		return indicePerformance;
	}

	public void setIndicePerformance(double indicePerformance) {
		this.indicePerformance = indicePerformance;
	}

	public double getMontantPrime() {
		return montantPrime;
	}

	public void setMontantPrime(double montantPrime) {
		this.montantPrime = montantPrime;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	@Override
	public void remunerer() {
		System.out.println("Calcul de la r�mun�ration du contrat d'assurance vie...");

	}

	
}

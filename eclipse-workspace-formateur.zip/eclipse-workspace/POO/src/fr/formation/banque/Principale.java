package fr.formation.banque;

import fr.formation.banque.portefeuille.Client;
import fr.formation.banque.produit.Compte;
import fr.formation.banque.produit.CompteCourant;
import fr.formation.banque.produit.CompteEpargne;

public class Principale {

	public static void main(String[] args) {

// Le code est int�gralement comment� car la classe Compte est devenue abstraite.		
		
//		
//		
//		
//		// Appel de la m�thode de classe getNbComptes() au travers du nom de la classe.
//		System.out.println("Nombre de comptes : " + Compte.getNbComptes());
//		
//		// Cr�ation d'un client n�cessaire pour cr�er des comptes
//		Client clt1 = new Client(1, "DUPONT", "Robert", "40 rue de la Paix", "75007", "Paris");
//				
//		// Cr�er un objet Compte
//		Compte cpt1 = new Compte(569235, 5000.00, clt1);
//		
//		System.out.println("Nombre de comptes : " + Compte.getNbComptes());
//		
//		/*
//		 * Compte cpt1;					Variable pour r�f�rencer l'objet
//		 * 
//		 * cpt1 = new Compte();			Cr�ation de l'objet et association � la variable
//		 */
//		
//		// Acc�der aux attributs pour initialiser l'objet
////		cpt1.numero = 569235;
////		cpt1.solde = 5000.00;
////		cpt1.client = "Robert DUPONT";
//		
//		
//		/*
//		 * 		cpt1.getClient().getPrenom()
//		 * 			
//		 * 		D�composable en : 
//		 * 	
//		 * 		Client c = cpt1.getClient();
//		 *      String nom = c.getNom();	
//		 */
//		System.out.println(
//				cpt1.getNumero() + " - " + cpt1.getSolde() +
//				" �, appartenant � " + cpt1.getClient().getPrenom() +
//				" " + cpt1.getClient().getNom() +
//				", habitant � " + cpt1.getClient().getAdresse().getVille()
//		);
//		
//		cpt1.crediter(200.00);
//		
//		System.out.println(
//				cpt1.getNumero() + " - " + cpt1.getSolde() +
//				" �, appartenant � " + cpt1.getClient().getPrenom() +
//				" " + cpt1.getClient().getNom() +
//				", habitant � " + cpt1.getClient().getAdresse().getVille()
//		);
//		
//		cpt1.debiter(50.00);
//		
//		System.out.println(
//				cpt1.getNumero() + " - " + cpt1.getSolde() +
//				" �, appartenant � " + cpt1.getClient().getPrenom() +
//				" " + cpt1.getClient().getNom() +
//				", habitant � " + cpt1.getClient().getAdresse().getVille()
//		);
//		
//		System.out.println(cpt1);   // cpt1 contient l'adresse m�moire de l'objet.
//		
//		Compte cpt2 = cpt1;			// On copie l'adresse contenue dans cpt1 dans cpt2 -> Deux r�f�rences au m�me objet !
//		
//		System.out.println(cpt2);
//		
//		Client clt2 = new Client(2, "DURAND", "St�phane", "Place du Ralliement", "49000", "Angers");
//		
//		Compte cpt3 = new Compte(896532, clt2);
//		
//		System.out.println("Nombre de comptes : " + Compte.getNbComptes());
//		
//		System.out.println(
//				cpt3.getNumero() + " - " + cpt3.getSolde() +
//				" �, appartenant � " + cpt3.getClient().getPrenom() +
//				" " + cpt3.getClient().getNom() +
//				", habitant � " + cpt3.getClient().getAdresse().getVille()
//		);
//		
////		Compte cpt4 = null;
////				
////		cpt4.debiter(500);
//		
//		System.out.println(" --- Utilisation des comptes courants --- ");
//		
//		CompteCourant cc1 = new CompteCourant(963123, 100.00, clt2, 500.00);
//		
//		cc1.debiter(900.00);
//		
//		System.out.println(
//				cc1.getNumero() + " - " + cc1.getSolde() + ", Autorisation de d�couvert : " + cc1.getAutorisation() + " �"
//		);
//
//		System.out.println(" --- Utilisation des comptes �pargnes --- ");
//		
//		CompteEpargne ce1 = new CompteEpargne(456236, 20000.00, clt2, 1.25, 23500.00);
//		
//		ce1.crediter(5000.00);
//		
//		System.out.println(
//				ce1.getNumero() + " - " + ce1.getSolde() +
//				", Taux : " + ce1.getTaux() + " %, Plafond : " + ce1.getPlafond() + " �"
//		);
//		
//		System.out.println(" --- Manipulation d'un tableau de comptes --- ");
//		
//		// On cr�� un tableau de comptes que l'on remplit avec les objets Compte, CompteEpargne et CompteCourant
//		// cr��s au dessus...
//		Compte[] lesComptes = {cpt1, cpt2, cpt3, cc1, ce1};
//		
//		// Pour chaque �l�ment que l'on appelle 'c' dans le tableau 'lesComptes'...
//		for(Compte c : lesComptes) {
//			System.out.print("Num�ro : " + c.getNumero() + ", Solde : " + c.getSolde());
//			if(c instanceof CompteEpargne) {
////				CompteEpargne ce = (CompteEpargne) c;
////				System.out.println(", Plafond : " + ce.getPlafond());
//				
//				System.out.print(", Plafond : " + ((CompteEpargne) c).getPlafond());
//			}
//			if(c instanceof CompteCourant) {
//				System.out.print(", Autorisation : " + ((CompteCourant) c).getAutorisation());	
//			}
//			System.out.println();
//		}
//	
//		Client clt4 = new Client(4, "DUPONT", "Robert", "40 rue de la Paix", "75007", "Paris");
//		Client clt5 = new Client(5, "DUPONT", "Martine", "40 rue de la Paix", "75007", "Paris");
//		Client clt6 = new Client(4, "DUPONT", "Robert", "40 rue de la Paix", "75007", "Paris");
//
//		System.out.println("clt4 et clt5 sont identiques ? : " + clt4.equals(clt5));
//		System.out.println("clt4 et clt6 sont identiques ? : " + clt4.equals(clt6));
//		System.out.println("clt5 et clt6 sont identiques ? : " + clt5.equals(clt6));
		
	}
}
